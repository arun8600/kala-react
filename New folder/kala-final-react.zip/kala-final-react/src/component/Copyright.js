import React from 'react'

function Copyright() {
    return (
        <div>
            <div className="copyright">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 col-md-12 col-sm-12 col-xl-12">
                            <div className="copy">
                                <p>2021 | Hyang Maha Hesa, Indonesia</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Copyright
