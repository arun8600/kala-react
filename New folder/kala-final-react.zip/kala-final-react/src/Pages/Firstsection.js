import React from 'react'

function Firstsection() {
    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col-lg-12 col-md-12 col-xl-12 col-sm-12">
                        <div className="title">
                            <h1><span>Welcome to</span> Kala Staking.</h1>
                            <p>In Kala, we Trust !</p>
                            <div className="sr-btn-wrap">
                                <a href="" className="sr-btn">Connect Wallet</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Firstsection
